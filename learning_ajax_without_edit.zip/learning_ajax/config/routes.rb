Rails.application.routes.draw do
	root 'courses#index'
end
