class CoursesController < ApplicationController
  def index
  end
end
